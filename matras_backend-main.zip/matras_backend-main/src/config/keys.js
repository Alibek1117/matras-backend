module.exports = {
    PORT: process.env.PORT,
    connectionString: process.env.DB_CONNNECT,
    pageLimit: 6,
    secretKey: process.env.SECRET_KEY
}